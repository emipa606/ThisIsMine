﻿using HarmonyLib;
using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Verse;
using Verse.AI;

namespace ThisIsMine
{
    [StaticConstructorOnStartup]
    public static class HarmonyInit
    {
        static HarmonyInit()
        {
            var harmony = new Harmony("Elseud.ThisIsMine");
            harmony.PatchAll();
            foreach (var furniture in DefDatabase<ThingDef>.AllDefs.Where(x => x.thingCategories?.Contains(ThingCategoryDef.Named("BuildingsFurniture")) ?? false))
            {
                if (!furniture.IsBed)
                {
                    if (furniture.comps is null)
                        furniture.comps = new List<CompProperties>();
                    furniture.comps.Add(new CompProperties_CanBelongToRoomOwners());
                }
            }
        }

        public static bool PawnCanHaveIt(Pawn pawn, Thing thing)
        {
            if (CompCanBelongToRoomOwners.privateThings.Contains(thing))
            {
                var comp = thing.TryGetComp<CompCanBelongToRoomOwners>();
                if (comp.belongsToCell.IsValid)
                {
                    var room = comp.belongsToCell.GetRoom(thing.Map);
                    if (room != null && room.Owners.Contains(pawn))
                    {
                        return true;
                    }
                }
                else if (thing.GetRoom() != null && thing.GetRoom().Owners.Contains(pawn))
                {
                    return true;
                }
                return false;
            }
            else if (thing.def.category == ThingCategory.Item)
            {
                if (Patch_SpawnSetup.storageCells.Contains(thing.Position))
                {
                    var container = thing.Position.GetFirstThing<Building_Storage>(pawn.Map);
                    if (container != null && container != thing && !PawnCanHaveIt(pawn, container))
                    {
                        return false;
                    }
                }
                else if (thing.ParentHolder is Building_Storage container2 && !PawnCanHaveIt(pawn, container2))
                {
                    return false;
                }
            }
            return true;
        }
    }

    [HarmonyPatch(typeof(Building_Storage), "SpawnSetup")]
    public static class Patch_SpawnSetup
    {
        public static HashSet<IntVec3> storageCells = new HashSet<IntVec3>();
        private static void Postfix(Building_Storage __instance)
        {
            storageCells.AddRange(__instance.AllSlotCells());
        }
    }


    [HarmonyPatch(typeof(ReservationManager), "CanReserve")]
    public static class Patch_CanReserve
    {
        private static void Postfix(ref bool __result, Pawn claimant, LocalTargetInfo target, int maxPawns = 1, int stackCount = -1, ReservationLayerDef layer = null, bool ignoreOtherReservations = false)
        {
            if (__result)
            {
                if (target.HasThing && !HarmonyInit.PawnCanHaveIt(claimant, target.Thing))
                {
                    __result = false;
                }
            }
        }
    }

    [HarmonyPatch(typeof(ForbidUtility), "IsForbidden", new Type[] { typeof(Thing), typeof(Pawn) })]
    public static class Patch_IsForbidden
    {
        private static void Postfix(ref bool __result, Thing t, Pawn pawn)
        {
            if (!__result)
            {
                if (!HarmonyInit.PawnCanHaveIt(pawn, t))
                {
                    __result = true;
                }
            }
        }
    }

    [HarmonyPatch(typeof(Toils_Ingest), "FindAdjacentEatSurface")]
    public static class Patch_FindAdjacentEatSurface
    {
        private static bool Prefix(ref Toil __result, TargetIndex eatSurfaceInd, TargetIndex foodInd)
        {
            Toil toil = new Toil();
            toil.initAction = delegate
            {
                Pawn actor = toil.actor;
                IntVec3 position = actor.Position;
                Map map = actor.Map;
                int num = 0;
                IntVec3 intVec;
                while (true)
                {
                    if (num >= 4)
                    {
                        return;
                    }
                    intVec = position + new Rot4(num).FacingCell;
                    if (CanEatOn(actor, intVec))
                    {
                        break;
                    }
                    num++;
                }
                toil.actor.CurJob.SetTarget(eatSurfaceInd, intVec);
                toil.actor.jobs.curDriver.rotateToFace = eatSurfaceInd;
                Thing thing = toil.actor.CurJob.GetTarget(foodInd).Thing;
                if (thing.def.rotatable)
                {
                    thing.Rotation = Rot4.FromIntVec3(intVec - toil.actor.Position);
                }
            };
            toil.defaultCompleteMode = ToilCompleteMode.Instant;
            __result = toil;
            return false;
        }

        private static bool CanEatOn(Pawn pawn, IntVec3 intVec)
        {
            List<Thing> thingList = intVec.GetThingList(pawn.Map);
            for (int i = 0; i < thingList.Count; i++)
            {
                if (thingList[i].def.surfaceType == SurfaceType.Eat && HarmonyInit.PawnCanHaveIt(pawn, thingList[i]))
                {
                    return true;
                }
            }
            return false;
        }
    }

    public class CompProperties_CanBelongToRoomOwners : CompProperties
    {
        public CompProperties_CanBelongToRoomOwners()
        {
            compClass = typeof(CompCanBelongToRoomOwners);
        }
    }

    public class CompCanBelongToRoomOwners : ThingComp
    {
        private bool belongsToRoomOwners;
        public IntVec3 belongsToCell = IntVec3.Invalid;
        public static HashSet<Thing> privateThings = new HashSet<Thing>();
        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
            if (this.belongsToRoomOwners)
            {
                privateThings.Add(this.parent);
            }
        }

        public override void PostDrawExtraSelectionOverlays()
        {
            base.PostDrawExtraSelectionOverlays();
            if (belongsToCell.IsValid)
            {
                GenDraw.DrawLineBetween(parent.TrueCenter(), belongsToCell.ToVector3());
            }
        }
        public static TargetingParameters ForRoom()
        {
            TargetingParameters targetingParameters = new TargetingParameters();
            targetingParameters.canTargetLocations = true;
            return targetingParameters;
        }
        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            Command_Action command_Action = new Command_Action();
            command_Action.defaultLabel = belongsToRoomOwners ? "TIM.BelongsToRoomPrivate".Translate() : "TIM.BelongsToRoomCommon".Translate();
            command_Action.icon = this.belongsToRoomOwners ? ContentFinder<Texture2D>.Get("UI/Commands/Icon-Public") : ContentFinder<Texture2D>.Get("UI/Commands/Icon-Assign_to_Bed");
            command_Action.defaultDesc = "TIM.BelongsToRoomDesc".Translate();
            command_Action.action = delegate
            {
                belongsToRoomOwners = !belongsToRoomOwners;
                if (this.belongsToRoomOwners)
                {
                    privateThings.Add(this.parent);
                }
                else
                {
                    privateThings.Remove(parent);
                }
            };
            command_Action.hotKey = KeyBindingDefOf.Misc2;
            yield return command_Action;

            yield return new Command_Action
            {
                action = delegate ()
                {
                    Find.Targeter.BeginTargeting(ForRoom(), delegate (LocalTargetInfo x)
                    {
                        this.belongsToCell = x.Cell;
                    }, null, null, null);
                },
                defaultLabel = "TIM.ConnectToRoom".Translate(),
                hotKey = KeyBindingDefOf.Misc3,
                defaultDesc = "TIM.ConnectToRoomDesc".Translate(),
                icon = ContentFinder<Texture2D>.Get("UI/Commands/AssignToRoomIcon", false)
            };
            yield return new Command_Action
            {
                action = delegate ()
                {
                    this.belongsToRoomOwners = false;
                    this.belongsToCell = IntVec3.Invalid;
                },
                defaultLabel = "TIM.UnassignFromRoom".Translate(),
                hotKey = KeyBindingDefOf.Misc4,
                defaultDesc = "TIM.UnassignFromRoomDesc".Translate(),
                icon = ContentFinder<Texture2D>.Get("UI/Commands/Icon-Unassign_from_room", false)
            };
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref belongsToRoomOwners, "belongsToRoomOwners");
            Scribe_Values.Look(ref belongsToCell, "belongsToCell");
        }
    }
}